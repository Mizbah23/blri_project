<table class="table table-responsive table-hover table-striped table-bordered table-condensed">
    <tr class="row bg-primary">
        <th class="col-lg-1 text-center">#</th>
        <th class="col-lg-2 text-center">Category</th>
        <th class="col-lg-8 text-center">Brand</th>
        <th class="col-lg-1 text-center">Edit</th>
    </tr>
    <?php if(isset($brands)): ?>
        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="row">
                <td><?php echo e(++$key); ?></td>
                <td><?php echo e($brand->category->categoryName); ?></td>
                <td><?php echo e($brand->brandName); ?></td>
                
                <td><a href="<?php echo e(route('setup.brandedit',[$brand->id])); ?>"><i class="fa fa-edit" style="font-size:24px"></i></a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</table><?php /**PATH G:\DSL Project\blri_project\blri\resources\views/setup/ajaxBrandSearchedValue.blade.php ENDPATH**/ ?>