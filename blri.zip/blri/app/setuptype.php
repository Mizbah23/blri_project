<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class setuptype extends Model
{
    //
}
