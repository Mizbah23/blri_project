<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tblpurchasedetails extends Model
{
    protected $table = 'tblpurchasedetails';
}
