<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tblpurchase extends Model
{
     /**
     * The tblpurchase associated with the model.
     */
    protected $table = 'tblpurchase';
}
