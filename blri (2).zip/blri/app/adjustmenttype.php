<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class adjustmenttype extends Model
{
    //
     protected $table = 'adjustmenttype';
     protected $primaryKey = 'AdjustmentTypeID';
     
}
