<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeAttendanceView extends Model
{
    protected $table = "employeeattendenceview";
}
