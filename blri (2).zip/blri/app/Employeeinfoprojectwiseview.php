<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Employeeinfoprojectwiseview extends Model
{
    protected $table = 'employeeinfoprojectwiseview';
}
