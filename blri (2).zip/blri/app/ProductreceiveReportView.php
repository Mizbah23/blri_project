<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductreceiveReportView extends Model
{
    protected $table = "productreceiveview";
}
