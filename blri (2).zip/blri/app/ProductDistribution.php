<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductDistribution extends Model
{
    //
}
