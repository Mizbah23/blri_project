<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class requisitioninfo extends Model
{
    protected $table = 'requisitioninfo';
}
