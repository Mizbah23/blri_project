<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class requisitiondetails extends Model
{
    //
}
