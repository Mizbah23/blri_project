<table class="table table-responsive table-hover table-striped table-bordered table-condensed">
    <tr class="bg-primary">
        <th>#</th>
        <th>অনুষদ</th>
        <th>সম্পাদনা</th>
    </tr>
    <?php if(isset($divisions)): ?>
        <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr scope="row">
            <td><?php echo e(++$key); ?></td>
            <td><?php echo e($division->divisionName); ?></td>
            <td>
                <a href="<?php echo e(route('setup.divedit',[$division->id])); ?>"><i class="fa fa-edit" style="font-size:24px"></i></a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</table><?php /**PATH G:\DSL Project\blri_project\blri\resources\views/setup/ajaxDivisionSearchedValue.blade.php ENDPATH**/ ?>