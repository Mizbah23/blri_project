<table class="table table-responsive table-hover table-striped table-bordered table-condensed">
    <thead class="bg-primary">
        <tr>
            <th>#</th>
            <th>ক্যাটাগরি</th>
            <th>সম্পাদনা</th>
        </tr>
    </thead>
    <?php if(isset($categories)): ?>
    <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e(++$key); ?></th>
            <td><?php echo e($category->categoryName); ?></td>
            <td>
                <a href="<?php echo e(route('setup.catedit',[$category->id])); ?>"><i class="fa fa-edit" style="font-size:24px"></i></a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <?php endif; ?>
</table><?php /**PATH G:\DSL Project\blri_project\blri\resources\views/setup/ajaxCategorySearchedValue.blade.php ENDPATH**/ ?>