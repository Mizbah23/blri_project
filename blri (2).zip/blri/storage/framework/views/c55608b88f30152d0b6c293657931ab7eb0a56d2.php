<form class="form-horizontal" method="post" autocomplete="off" id="editForm"> 
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <div class="form-group"> <!--Form-->

      <div class="row">
          <div class="col-md-4" >
              <div class="col-md-3">
                   <label for="supplierName" class=" control-label">Supplier</label>
              </div>
              <div class="col-md-9">
                  <select id="supplierName" name="supplierName" class="form-control required" required onchange="showSupplierOtherInfo()">
                   <option value="">Select Supplier</option>
                   <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($supplier->id); ?>" <?php if(old('supplierName',$productReceiveList->supplier_id)==$supplier->id): ?>
                        <?php echo e("selected"); ?>

                    <?php endif; ?>><?php echo e($supplier->supplierName); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="error"><?php echo e($errors->first('supplierName')); ?></div>
              </div><br><br>

              <div class="col-md-3">
                   <label for="productName" class=" control-label">Product</label>
              </div>
              <div class="col-md-9">
                  <select id="productName" name="productName" class="form-control required" required onchange="showProductCode()">
                   <option value="">Select Product</option>
                   <?php $__currentLoopData = $products->unique('productName')->pluck('productName'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($productName); ?>" <?php if(old('productName',$productReceiveList->productInfo->productName)==$productName): ?>
                      <?php echo e("selected"); ?>

                  <?php endif; ?>><?php echo e($productName); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="error"><?php echo e($errors->first('productName')); ?></div>
              </div><br><br>

              <div class="col-md-3">
                <label for="productCode" class=" control-label">Product Code</label>
              </div>
              <div class="col-md-9">
                <select id="productCode" name="productCode" class="form-control required" required>
                 <option value="">Select Product Code</option>
                 <?php if(old('productName',$productReceiveList->productInfo->productName)): ?>
                  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if(old('productName',$productReceiveList->productInfo->productName)==$product->productName): ?>
                    <option value="<?php echo e($product->id); ?>" <?php if(old('productCode',$productReceiveList->productInfo->id)==$product->id): ?>
                        <?php echo e("selected"); ?>

                    <?php endif; ?>><?php echo e($product->productCode); ?></option>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </select>
              <div class="error"><?php echo e($errors->first('productCode')); ?></div>
            </div><br><br>

              
         </div>

          <div class="col-md-4" >
              
          <div class="col-md-3">
              <label for="address" class=" control-label">Address</label>
              </div>
              <div class="col-md-9">
                 <input type="text" class="form-control" id="address" name="address" value="<?php echo e(old('address',$productReceiveList->supplierInfo->address)); ?>" placeholder="Address can not be empty" required readonly>
                 <div class="error"><?php echo e($errors->first('address',$productReceiveList->supplierInfo->contactNo)); ?></div>
              </div><br><br>

              <div class="col-md-3">
                <label for="orderNo" class=" control-label">OrderNo.</label>
              </div>
              <div class="col-md-9">
                <input type="text" class="form-control" id="orderNo" name="orderNo" value="<?php echo e(old('orderNo',$productReceiveList->orderNo)); ?>" placeholder="Order no can not be empty"required>
                <div class="error"><?php echo e($errors->first('orderNo')); ?></div>
              </div><br><br>


              <div class="col-md-3">
              <label for="projectName" class=" control-label">Project</label>
              </div>
              <div class="col-md-9">
                  <select id="projectName" name="projectName" class="form-control required" required>
                   <option value="">Select Project</option>
                   <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($project->id); ?>" <?php if(old('projectName',$productReceiveList->project_id)==$project->id): ?>
                      <?php echo e("selected"); ?>

                  <?php endif; ?>><?php echo e($project->projectName); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="error"><?php echo e($errors->first('projectName')); ?></div>
              </div><br><br>

              <div class="col-md-3">
              
              </div>

          </div>

          <div class="col-md-4" >
              <div class="col-md-3">
               <label for="contactNo" class=" control-label">Mobile</label>
              </div>
              <div class="col-md-9">
                 <input type="text" class="form-control" id="contactNo" name="contactNo" value="<?php echo e(old('contactNo',$productReceiveList->supplierInfo->mobile)); ?>" placeholder="Mobile no can not be empty" required readonly>
                <div class="error"><?php echo e($errors->first('contactNo')); ?></div>
              </div><br><br>

              <div class="col-md-3">
              <label for="quantity" class=" control-label">Quantity</label>
              </div>
              <div class="col-md-9">
                 <input type="number" class="form-control" id="quantity" name="quantity" value="<?php echo e(old('quantity',$productReceiveList->quantity)); ?>" placeholder="Quantity can not be empty" required>
                 <div class="error"><?php echo e($errors->first('quantity')); ?></div>
              </div>
              <br><br>

              <div class="col-md-3">
              <label for="" class=" control-label">Date</label>
              </div>
              <div class="col-md-9">
                <input class="form-control datepicker" type="text" id="receiveDate" name="receiveDate" placeholder="mm/dd/yyyy"  value="<?php echo e(old('receiveDate',date('m/d/Y',strtotime($productReceiveList->receiveDate)))); ?>"  required><br>
                <div class="error"><?php echo e($errors->first('receiveDate')); ?></div>
              </div><br><br>
          
          </div>
          <div class="text-center">
            <input type="hidden" name="productReceiveListId" value="<?php echo e($productReceiveList->id); ?>">
            <button type="button" onclick="updateContent()" class="btn btn-success"><i class="glyphicon glyphicon-edit" style="color: white"></i> হালনাগাদ করুন</button> 
            <button type="button" class="btn btn-danger" onclick="cancelUpdate()">বাতিল করুন</button><br><br>
          </div>

    </div>
    
  </div>
</form><?php /**PATH G:\DSL Project\blri_project\blri\resources\views/product receive/ajaxEditProductReceive.blade.php ENDPATH**/ ?>