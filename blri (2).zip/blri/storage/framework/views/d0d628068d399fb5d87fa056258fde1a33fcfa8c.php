<form class="form-horizontal" method="post" autocomplete="off" id="editForm"> 
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
 <div class="form-group">
                          
                          <div class="row" style="border: solid 1px #eee; padding: 20px">
                              <div class="col-md-3"></div>
                  
                  
                              <div class="col-md-6">
                                  <div class="col-md-3">
                                      <label for="divisionName" class="col-sm-2 control-label">অনুষদ</label>
                                  </div>
                                  <div class="col-md-9">
                                      <select class="form-control" id="divisionName" name="divisionName">
                                          <option value="">নির্বাচন করুন</option>
                                          <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($division->id); ?>" <?php if(old('divisionName',$productDistributionList->division_id)==$division->id): ?>
                                              <?php echo e("selected"); ?>

                                          <?php endif; ?>><?php echo e($division->divisionName); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                  </div><br><br>
                              </div>
                              <div class="col-md-3"></div>
                  
                          </div><br>
                  
                  
                          <div class="row">
                              <div class="col-md-5" style="border: solid 2px #eee; padding: 20px">
                                  <div class="col-md-4">
                                      <label for="categoryName" class=" control-label">ক্যাটাগরি</label>
                                  </div>
                                  <div class="col-md-8">
                                      <select id="categoryName" name="categoryName" onchange="showBrand()" class="form-control required"
                                          required >
                                          <div class="error" style="color:red"><?php echo e($errors->first('categoryName')); ?></div><br><br>
                                          <option value="">নির্বাচন করুন</option>
                                          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($category->id); ?>"
                                              <?php echo e(old('categoryName',$productDistributionList->serialInfo->productInfo->brand->category->id)==$category->id ?"selected":""); ?>>
                                              <?php echo e($category->categoryName); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                  </div><br><br>
                                  <div class="col-md-4">
                                      <label for="brandName" class=" control-label">ব্র্যান্ড</label>
                                  </div>
                                  <div class="col-md-8">
                                      <select id="brandName" name="brandName" class="form-control required" required
                                          onchange="showProductName()">
                                          <div class="error" style="color:red"><?php echo e($errors->first('brandName')); ?></div><br><br>
                                          <option value="">ব্র্যান্ড নির্বাচন করুন</option>
                                          <?php if(old('categoryName',$productDistributionList->serialInfo->productInfo->brand->category->id)): ?>
                                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(old('categoryName',$productDistributionList->serialInfo->productInfo->brand->category->id) == $brand->category->id): ?>
                                                <option value="<?php echo e($brand->id); ?>" <?php echo e(old('brandName',$productDistributionList->serialInfo->productInfo->brand_id)==$brand->id?"selected":""); ?>>
                                                    <?php echo e($brand->brandName); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          <?php endif; ?>
                  
                                      </select>
                                  </div><br><br>
                                  <div class="col-md-4">
                                      <label for="productName" class=" control-label">পণ্য</label>
                                  </div>
                                  <div class="col-md-8">
                                      <select class="form-control" id="productName" name="productName" required onchange="showSerialInfo()">
                                        <option value="">পণ্য শনাক্ত করুন</option>
                                        <?php if(old('brandName',$productDistributionList->serialInfo->productInfo->brand_id)): ?>
                                        <?php $__currentLoopData = $selectedProductBasedOnBrand->unique('productName'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($product->id); ?>" <?php if(old('productName',$productDistributionList->serialInfo->product_info_id)==$product->id): ?>
                                            <?php echo e("selected"); ?>

                                            <?php endif; ?>><?php echo e($product->productName); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                      </select>
                                  </div><br><br>

                                  <div class="col-md-4">
                                      <label for="serial_no" class="control-label">সিরিয়াল নং</label>
                                  </div>
                                  <div class="col-md-8">
                                      <select id="serial_no" name="serial_no" class="form-control required" value="<?php echo e(old('serial_no')); ?>"required readonly>
                                        <option value="">সিরিয়াল নং নির্বাচন করুন</option>
                                        <?php if(old('productName',$productDistributionList->serialInfo->product_info_id)): ?>
                                            <?php $__currentLoopData = $serialInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serialInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(old('productName',$productDistributionList->serialInfo->product_info_id)==$serialInfo->product_info_id): ?>
                                                <option value="<?php echo e($serialInfo->id); ?>" <?php if(old('serial_no',$productDistributionList->serial_id)==$serialInfo->id): ?>
                                                <?php echo e("selected"); ?>

                                                <?php endif; ?>><?php echo e($serialInfo->serial_no); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                  
                                      </select>
                                  </div><br><br>
                                  <div class="col-md-4">
                                      <label for="remarks" class=" control-label">মন্তব্য</label>
                                  </div>
                                  <div class="col-md-8">
                                      <textarea class="form-control" id="remarks" name="remarks" placeholder=""><?php echo e(old('remarks',$productDistributionList->remarks)); ?></textarea><br><br>
                  
                                  </div><br><br>
          <div class="text-center">
            <input type="hidden" name="productDistributionListId" value="<?php echo e($productDistributionList->id); ?>">
            <button type="button" onclick="updateContent()" class="btn btn-success"><i class="glyphicon glyphicon-edit" style="color: white"></i> হালনাগাদ করুন</button> 
            <button type="button" class="btn btn-danger" onclick="cancelUpdate()">বাতিল করুন</button><br><br>
          </div>

    </div>
    
  </div>
</div>
</form><?php /**PATH G:\DSL Project\blri_project\blri\resources\views/product distribution/ajaxEditDistribution.blade.php ENDPATH**/ ?>