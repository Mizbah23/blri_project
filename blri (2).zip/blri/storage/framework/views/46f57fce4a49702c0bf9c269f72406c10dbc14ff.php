!<DOCTYPE html>
<html lang="bn">
<head>
	<title></title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <style type="text/css">
    body {
    font-family: 'kalpurush', sans-serif,'ShonarBangla','Bijoy';
}

table{
        width: 70%;
        margin: 0 auto;
        border: 1px solid;
        border-collapse: collapse;
	}
th,td{
 border: 1px solid;
 padding-left: 5px;
}

</style>
</head>
<body>
  <h1 style="margin-left:15%">বাংলাদেশ প্রাণিসম্পদ গবেষণা ইনস্টিটিউট</h1>
  
   <center>
     <table>
       <thead>
        <tr>
       </tr>
       </thead>
       <tbody> 
        <tr>
        </tr>
       </tbody>
   </table>
   </center>
</body>
</html><?php /**PATH G:\DSL Project\blri_project\blri\resources\views/product receive/productReceiveInvoice.blade.php ENDPATH**/ ?>