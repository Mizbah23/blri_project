<form class="form-horizontal" method="post" autocomplete="off" id="editForm" > <!--Form for grideview-->
  <?php echo method_field('put'); ?>
  <?php echo csrf_field(); ?>
  <div class="form-group">
      <div class="row" style="border:2px solid #EEE;padding:20px">

      

      <div class="col-lg-4">
          
        <label for="releaseDate"><b>খালাসের তারিখ:</b></label>
        <input type="text" class="form-control datepicker" name="releaseDate" placeholder="dd/mm/yyyy" value="<?php echo e(old('releaseDate',date('d/m/Y',strtotime(str_replace('-','/',$availableProductReleaseInfo->releaseDate))))); ?>" required>
        <div class="error"><?php echo e($errors->first('releaseDate')); ?></div><br>
        <label for="deptName"><b>বিভাগের নাম:</b></label>
        <select id="deptName" name="deptName" class="form-control required" required>
          <option value="">নির্বাচন করুন</option>
          <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <option value="<?php echo e($division->id); ?>" <?php if(old('deptName',$availableProductReleaseInfo->division_id)==$division->id): ?>
             <?php echo e("selected"); ?>

         <?php endif; ?> ><?php echo e($division->divisionName); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </select>
       <div class="error"><?php echo e($errors->first('deptName')); ?></div>
      </div>

      <div class="col-lg-1"></div>

      <div class="col-lg-4">
        <label for="project"><b>প্রকল্প:</b></label><br>
        <select id="projectName" name="projectName" onchange="showEmployee()" class="form-control required" required>
          <option value="">নির্বাচন করুন</option>
          <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($project->id); ?>" <?php if(old('projectName',$availableProductReleaseInfo->project_id)==$project->id): ?>
              <?php echo e("selected"); ?>

          <?php endif; ?> ><?php echo e($project->projectName); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </select><br>
       <div class="error"><?php echo e($errors->first('projectName')); ?></div>
        <label for="employee"><b>কর্মকর্তা:</b></label><br>
        <select id="employeeName" name="employeeName" class="form-control required" required>
          <option value="">নির্বাচন করুন</option>
          <?php if(old('projectName',$availableProductReleaseInfo->project_id)): ?>
           <?php $__currentLoopData = $assignedEmployees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$assignedEmployee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <option value="<?php echo e($assignedEmployee->id); ?>" <?php if(old('employeeName',$availableProductReleaseInfo->employee_information_id)==$assignedEmployee->id): ?>
               <?php echo e("selected"); ?> 
               <?php endif; ?>><?php echo e($assignedEmployee->name); ?>

             </option>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
          
       </select>
       <div class="error"><?php echo e($errors->first('employeeName')); ?></div>
      </div>
      </div>  
  </div>
  
  <div class="row" style="border:2px solid #EEE;padding:15px;margin: -16px">
    <div class="col-lg-5">
    <label for="serialNo"><b>সিরিয়াল নং</b></label>
    <select id="serialNo" name="serialNo" class="form-control required" required>
        <option value="">Select serial No of Product</option>
        <?php $__currentLoopData = $serialInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($item->id); ?>" <?php if(old('serialNo',$availableProductReleaseInfo->serial_info_id)==$item->id): ?>
            <?php echo e("selected"); ?>

        <?php endif; ?> ><?php echo e($item->serial_no); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <div class="error"><?php echo e($errors->first('serialNo')); ?></div>
    <br>
    <center>
      <input type="hidden" name="productReleaseInfoId" value="<?php echo e($availableProductReleaseInfo->id); ?>">
      <button type="button" class="btn btn-success" onclick="updateContent()"><i class="glyphicon glyphicon-edit"
      style="color:white" ></i>হালনাগাদ করুন</button>
      <button type="button"class="btn btn-danger">বাতিল করুন</button>
    </center>
    </div>
       
     <div class="col-lg-7"><br>
         <table class="table table-responsive table-hover table-striped table-bordered table-condensed">
            <thead >
              <tr class="row bg-primary">
              
              <th class="col-lg-2 text-center">পণ্যের নাম</th>
              <th class="col-lg-3 text-center">সিরিয়াল নং</th>
              <th class="col-lg-3 text-center">কর্মকর্তার নাম</th>
              <th class="col-lg-3 text-center">বিভাগ</th>
              <th class="col-lg-3 text-center">সম্পাদনা</th>
              <th class="col-lg-3 text-center">মুছে ফেলুন</th>
              </tr>
            </thead>
            <tbody  align="center">
              <?php $__currentLoopData = $productReleaseInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($item->status=="pending"): ?>
              <tr class="row">
                
                <td><?php echo e($item->serialInfo->productInfo->productName); ?></td>
                <td><?php echo e($item->serialInfo->serial_no); ?></td>
                <td><?php echo e($item->employeeinfo->name); ?></td>
                <td><?php echo e($item->division->divisionName); ?></td>
                 <td class="text-center"> <a href="#"class="glyphicon glyphicon-edit" onclick="handleEdit($item->id)" style="font-size:24px; color: #1bc9f5"></i></a></td>
                   <td> <a href="#" onclick="deleteItem(<?php echo e($item->id); ?>)" class="glyphicon glyphicon-trash" style="font-size:24px"></i></a></td>
              </tr>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
         </table>
     </div>
  </div>
</form><?php /**PATH G:\DSL Project\blri_project\blri\resources\views/product distribution/ajaxEditProductRelease.blade.php ENDPATH**/ ?>